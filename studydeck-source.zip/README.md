# StudyDeck

A local-first study cockpit: weekly timetable, tasks with reminders, focus timer, calendar,
curated free resources, and a study coach. Everything is stored in your browser's local storage —
no account, no server, no data leaves the machine.

## First run

A short eight-step tour opens on the first visit and walks through the timetable, tasks and
duties, focus timer, calendar, resources, the floating coach/music buttons and backups. You can skip
it, and replay it any time from **Settings → Getting started**. Completing or skipping it is remembered.

## Run it

```bash
npm install
npm run dev      # http://localhost:5174
npm run build    # typecheck + production build into dist/
npm run preview  # serve the built app
```

## What's inside

| View | What it does |
| --- | --- |
| **Today** | Greeting, what's happening now/next, open tasks, upcoming dates, quick-add, focus progress |
| **Timetable** | Week grid with coloured blocks; click a block to edit, click a column to add |
| **Tasks** | Add/tick/delete tasks, priorities, due dates, reminders, filters, plus recurring duties |
| **Focus** | Countdown (15/25/45/60/custom) and stopwatch with laps; finished sessions are logged |
| **Calendar** | Month view for exams, deadlines, holidays and personal dates |
| **Resources** | 32 free study sites plus AI tutors and virtual labs; add your own links |
| **Study coach** | Floating button (bottom-right) opens a chat panel; use the API or the built-in offline coach |
| **Settings** | Name, daily goal, AI provider, notifications, backup export/import, reset |
| **Lock-in** | Floating music button: four generated soundscapes and your own tracks (files or links) |

## The AI assistant

The coach is not a separate page: a floating button sits in the bottom-right corner of every view
and opens a chat panel over whatever you are doing. `Esc` or the X closes it, the reset icon clears
the conversation, and messages stay saved between sessions.

Pick a provider in **Settings → AI assistant**:

1. **Offline coach (default)** — rule-based guidance for planning, maths, essays, coding,
   cyber security and motivation. It gives method, not answers, and is clearly labelled as not AI.
2. **Local model (no API key)** — run Llama or any compatible model on your own computer with
   [Ollama](https://ollama.com) (`http://localhost:11434/v1`) or LM Studio
   (`http://localhost:1234/v1`). Requests carry no `Authorization` header at all. *Check server*
   lists the models you have pulled so you can pick one.
3. **OpenAI-compatible** — hosted endpoints such as OpenAI or Groq
   (`https://api.groq.com/openai/v1`); these always need a key. A **Groq preset** fills in the base
   URL, but Groq cannot run keyless — it is someone else's server. Model IDs live at
   console.groq.com/docs/models.
4. **Rasa** — connect your own Rasa bot server (see below).

So if "no API key" is the goal, use the **Local model** provider. On a laptop a 3B–8B model
(`llama3.2`, `qwen2.5`, `mistral`) is the sensible size; bigger models need more RAM and respond
slowly.

The key is kept in local storage and sent only to the endpoint you configure. It is not suitable
for a shared computer.

> If the endpoint rejects the browser request with a CORS error, run the model locally or put a
> small proxy in front of it.

### Connecting Rasa

Rasa is a conversational bot server you run yourself; this app talks to its REST channel and does
not train or host a model.

1. In `credentials.yml`, enable the REST channel:
   ```yaml
   rest:
   ```
2. Train and start the server with the API and CORS enabled:
   ```bash
   rasa train
   rasa run --enable-api --cors "*"
   ```
3. In StudyDeck, open **Settings → AI assistant → Rasa** and set the server URL
   (default `http://localhost:5005`).

Each browser gets a stable sender id, so Rasa keeps one conversation tracker per device. Replies
are whatever your stories/rules produce; multiple text messages in one Rasa response are joined
into one bubble. Buttons, images and custom payloads are ignored for now.

If the browser blocks the request, CORS is the usual cause — `--cors "*"` covers local use, and a
reverse proxy is the alternative.

## Lock-in music

A second floating button opens the music panel. Everything plays locally:

- **Soundscapes** — lo-fi keys, brown noise, rain and a warm pad, synthesised with the Web Audio
  API. No audio files, no streaming, no copyright issues.
- **Your music** — add tracks straight from this computer (stored as blobs in IndexedDB, so they
  survive a reload) or paste a direct audio URL (`.mp3`, `.ogg`, `.m4a`). Spotify and YouTube pages
  will not play — they are not audio files.

Volume is remembered, the panel can be closed without stopping playback, and one track plays at a
 time (with next/previous and auto-advance).

## Accounts and cloud backup (optional)

The app works fully without an account. If you want your data back on another device, connect a free
Supabase project:

1. Create a project at [supabase.com](https://supabase.com) (free tier).
2. Open **SQL editor → New query**, paste [`supabase/schema.sql`](supabase/schema.sql) and run it.
   That creates the `studydeck_snapshots` table and row-level policies so an account can only read
   its own row.
3. In **Project settings → API**, copy the **Project URL** and the **anon public** key.
4. In StudyDeck: **Settings → Account & cloud backup**, paste both, then **Create account** with an
   email and password. If your project requires email confirmation, confirm the message before
   signing in.
5. **Back up now** uploads the snapshot. On another device, sign in to the same account and press
   **Restore from cloud**. **Auto-sync** keeps pushing changes a few seconds after you make them.

What is uploaded: timetable, tasks, duties, calendar, focus history, resources, coach chat,
preferences (name, goal, AI provider/model settings) and the onboarding flag.
What is **never** uploaded: API keys, the Supabase anon key, and audio files in the music library.

Restoring replaces the data on the current device, so export a local backup first if unsure. The
anon key is public by design — the security boundary is the row-level policy in the SQL file, so do
not skip it.

> Verified against the UI and error paths only. A real Supabase project is required to exercise
> sign-up, upload and restore; that has not been run here.

## Reminders

Reminders are checked every 30 seconds and shown as desktop notifications, which requires
permission (Tasks → *Enable reminders*) and the app staying open. A packaged desktop build could
keep running in the background.

There are two kinds:

- **Task reminders** — one-off, for a specific date and time. Fire once.
- **Duty reminders** — recurring chores and assignment checks (every day, school days, or a chosen
  weekday). A duty appears on Today only on its scheduled days, resets each day, and alerts once per
  due day at the time you set. Tick it in Today or Tasks; the tick history is kept per date.

## Desktop packaging

The app is a static bundle, so it can be wrapped with Tauri or Electron without changing any
pages. For the simplest install, open it in Chrome/Edge and choose **Install StudyDeck**.

## Stack

React 18, TypeScript, Vite 6. No UI framework, no backend, no analytics.
